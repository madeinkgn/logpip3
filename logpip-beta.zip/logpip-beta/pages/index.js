// Sample index page
export default function Home() { return <div>Welcome to LogPip Beta</div>; }